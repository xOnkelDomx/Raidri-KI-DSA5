# Raidri-KI-DSA5

Ein FoundryVTT-Modul zur Automatisierung von Kampfhandlungen für DSA5-NPCs.